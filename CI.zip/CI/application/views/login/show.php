<?php
/**
 * Created by PhpStorm.
 * User: naveen
 * Date: 29/1/17
 * Time: 6:22 PM
 */

echo "<table border='1' align='center' cellpadding='10px'><tr><th>Name</th><th>Email</th></tr>";
foreach ($h->result() as $row)
{

     echo "<tr><td>$row->first_name</td><td>$row->email</td></tr>";


}
echo "</table>";
?>