<?php
class Login_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }
    public function set_news($data)
    {
        return $this->db->insert('newUsers', $data);
    }
    public function get_news()
    {

        $query = $this->db->get('newUsers');
        return $query;

    }
}