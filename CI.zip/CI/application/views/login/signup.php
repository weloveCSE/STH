<html>
<head>
<?php echo link_tag('resources/bootstrap.min.css');?>
</head>
<body>
<div class="container-fluid">
    <div class="row"><?php echo br(7);?>
        <div class="col-lg-offset-4 col-lg-4">
            <div class="well">
                <?php
                    echo form_open('login/signup');
                    echo '<label>First Name:</label> '.form_input('first_name','','placeholder="First Name" class="form-control"');
                    echo '<label>Last Name:</label> '.form_input('last_name','','placeholder="First Name" class="form-control"');
                    echo '<label>E-mail:</label> '.form_input('email','','placeholder="First Name" class="form-control"');
                    echo '<label>Username:</label> '.form_input('username','','placeholder="First Name" class="form-control"').br();
                    echo '<label>Password:</label> '.form_password('password','','placeholder="Password"').br(2);
                    echo '<label>Confirm Password:</label> '.form_password('confirm_password','','placeholder="Confirm password"').br();
                    echo form_submit('submit','Create');
                    ?>
                <?php echo validation_errors('<p style="color: red" >'); ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>