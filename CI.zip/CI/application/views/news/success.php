<?php
echo "Successfully inserted";
echo "Navee Kumar";
?>
