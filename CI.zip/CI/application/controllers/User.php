<?php
class User extends CI_Controller {
    function index(){
        $this->load->helper('html');

        $this->load->helper('url');

        $this->load->helper('form');
        $this->load->view('view_register');

    }
    public  function validate(){
        $this->load->helper('html');

        $this->load->helper('url');

        $this->load->helper('form');

        $this->load->library('form_validation');

        $this->form_validation->set_rules('username','Username','trim|required|required|alpha_numeric|min_length[6]|xss_clean');
        $this->form_validation->set_rules('name','Name','trim|required|alpha_numeric|min_length[6]');
        $this->form_validation->set_rules('email','Email','trim|required|alpha_numeric|min_length[6]');
        $this->form_validation->set_rules('password','Password','trim|required|alpha_numeric|min_length[6]');
        $this->form_validation->set_rules('password_conf','Password','trim|required|alpha_numeric|min_length[6]|matches[password]');


        if($this->form_validation->run() == FALSE){
            //THERE OR VALIDATION ERRORS
            $this->load->view('view_register');


        }
        else{
            //everything is good.
            echo "fun everything";

        }
    }

}
