<?php
class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->helper('url_helper');
        $this->load->database();
    }

   public function  index(){
       $this->load->helper('html');
       $this->load->helper('url');
       $this->load->helper('form');//It loads form helper
       $this->load->library('form_validation');
       $data['page_header']="Login Form";
       $this->load->view('login/index',$data);
   }
   public  function  validate(){
       $this->load->helper('html');
       $this->load->helper('url');
       $this->load->helper('form');

       $data['h'] = $this->login_model->get_news();
     // echo $data['details'];
       $this->load->view('login/show',$data);
   }
   public  function  signup(){
       $this->load->helper('html');
       $this->load->helper('url');
       $this->load->helper('form');
       $this->load->library('form_validation');
       $this->form_validation->set_rules('first_name','Name','trim|required');
       $this->form_validation->set_rules('last_name','Last Name','trim|required');
       $this->form_validation->set_rules('email','E-mail','trim|required|valid_email');
       $this->form_validation->set_rules('username','Username','trim|required|min_length[4]');
       $this->form_validation->set_rules('password','Password','trim|required|min_length[4]|max_length[32]');
       $this->form_validation->set_rules('confirm_password','Password confirmation','trim|required|matches[password]');
       if($this->form_validation->run()==FALSE){
           $this->load->view('login/signup');
       }
       else{
           $data=array(
               'first_name'=>$this->input->post('first_name'),
               'last_name'=>$this->input->post('last_name'),
               'email'=>$this->input->post('email'),
               'username'=>$this->input->post('username'),
               'password'=>md5($this->input->post('password'))

           );
           $this->login_model->set_news($data);
           $this->load->view('login/success');

       }
   }
}