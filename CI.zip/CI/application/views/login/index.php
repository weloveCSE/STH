<?php echo doctype('html5');?>
<html lang="en">
<head>



    <?php echo meta('description','My CI Site');?>
    <?php echo link_tag('resources/bootstrap.min.css');?>
</head>
<body>
<div class="container-fluid">
    <div class="row"><?php echo br(7);?>
        <div class="col-lg-offset-4 col-lg-4">
            <div class="well">
                <h2>Login  please..</h2><?php echo br();?>
                <?php
                    echo form_open('login/validate');?>
                    <label>Username:</label> <?php echo form_input('username','','placeholder="Username" class="form-control"').br(1);?>
                <label>Password:</label><?php echo form_password('password','','placeholder="Password" class="form-control"');?>
                <?php
                    echo br();
                    echo form_submit('submit','Login','class="btn btn-md btn-success"');
                    echo anchor('login/signup','Create Account');

                ?>

            </div>
        </div>
    </div>
</div>
</body>


</html>
